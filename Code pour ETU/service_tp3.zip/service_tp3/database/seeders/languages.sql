INSERT INTO `languages` (`id`, `name`) VALUES
(1, 'English'),
(2, 'Italian'),
(3, 'Japanese'),
(4, 'Mandarin'),
(5, 'French'),
(6, 'German');