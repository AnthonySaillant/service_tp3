
INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'user'),
(2, 'admin');
