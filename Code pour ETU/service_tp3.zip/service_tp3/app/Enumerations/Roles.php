<?php

namespace App\Enumerations;

enum Roles : int
{
    case USER = 1;
    case ADMIN = 2;
}
?>